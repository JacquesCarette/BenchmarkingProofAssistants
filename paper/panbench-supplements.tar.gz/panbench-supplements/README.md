# Panbench Supplementary Materials

This directory contains supplementary materials for 
the ITP'26 submission "Panbench: A Comparative Benchmarking Tool for Dependently-Typed Languages".

- `panbench-source` contains an anonymized copy of the source code of the
  `panbench` system.
- `report.html` contains a standalone HTML report detailing a full run of `panbench`.
- `pgf` contains the source code for PGF plots that summarize a full run of `panbench`
- `plots.pdf` contains PGF plots for all benchmarks in the `panbench` suite in a single PDF.
- `plots.tex` contains the TeX source used to generate `plots.pdf`.
