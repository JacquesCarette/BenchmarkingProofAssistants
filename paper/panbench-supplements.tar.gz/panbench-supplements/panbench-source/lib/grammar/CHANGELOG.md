# 0.2.0.0

* Reorganized directory structure to use the standard `app`, `src`, `test` convention.
* Added golden tests, which can be run with `cabal test translator`. See CONTRIBUTING.md
  for more documentation.


# 0.1.0.0

Initial release.
